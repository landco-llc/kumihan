# Offline installation / オフライン導入

This is a Private 0.1.0 candidate, not a published Release. Obtain the matching ZIP through the approved Private Git checkout/downloads directory; verify SHA256SUMS first. / Private候補のZIPを入手しSHA256SUMSで照合してください。未公開です。

GPT/Codex: extract a standalone Skill folder into the host's configured skills directory, or install the GPT-Codex plugin folder using the host's local plugin flow. Claude Code: add the extracted plugin folder as a local plugin (`claude --plugin-dir /absolute/path/kumihan-measure`); standalone Skills go in `.claude/skills/`. Gemini CLI: `gemini extensions link /absolute/path/kumihan-measure`; standalone Skills go in the host-configured skills directory if supported. Check your installed CLI's help before running version-specific commands.

各ホストのローカル導入先へ展開します。Claude/Geminiを含む全ZIPに公式PNGを同梱しています。ネイティブホスト実機の受入は未確認です。

For updates, inspect `codex --version`, `claude --version`, or `gemini --version`, compare package inventory version and hashes, then replace the approved local package using that host's documented update flow. Preserve user edits first. No nonexistent Release/update endpoint is required. Run `python runtime/check_source.py SOURCE --locale en-US --medium review` in any extracted Skill folder. The checker reads but never rewrites the source.
