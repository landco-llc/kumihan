---
name: kumihan-compasso
description: "Organiza tipografia portuguesa e design com respeito ao original. | Portuguese typography and design with source preservation."
---

# KUMIHAN｜Compasso

Consulte skills/kumihan-compasso/SKILL.md, rules/catalog.json, locales/house-styles.json e sources.json. Preserve o original; selecione país, meio e manual de estilo. / Preserve source and choose market, medium and house style.
