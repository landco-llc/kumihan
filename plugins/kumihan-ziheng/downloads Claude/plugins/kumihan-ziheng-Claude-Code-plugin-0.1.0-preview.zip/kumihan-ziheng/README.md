# KUMIHAN｜字衡 — Claude Code

臺灣（zh-Hant-TW）與香港（zh-Hant-HK）的繁體中文文字組版。
Traditional Chinese typography guidance for Taiwan and Hong Kong.

Version 0.1.0-preview. Four skills in `skills/`. The plugin is independently installable.
Use Claude Code's plugin import or local `claude --plugin-dir` on the extracted folder.
To install individual skills in Claude chat, use the four separately packaged skill ZIPs.
The original source text is protected; this is guidance, not a renderer.
