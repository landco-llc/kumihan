# KUMIHAN｜字衡 — Gemini CLI

臺灣（zh-Hant-TW）及香港（zh-Hant-HK）繁體中文文字組版。
Traditional Chinese typography guidance for Taiwan and Hong Kong.

Version 0.1.0-preview. Four skills in `skills/`.
Extract the extension ZIP into an empty local folder, then run `gemini extensions install /absolute/path/to/folder`.
The Japanese KUMIHAN GitHub repository root is a different Gemini extension: do NOT install its root URL expecting ZiHeng.
For Gemini app imports, use the four independent flat skill ZIPs.
Actual host discovery and invocation require separate acceptance testing.
